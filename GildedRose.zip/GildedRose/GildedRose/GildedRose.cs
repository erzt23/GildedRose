﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Data;
using System.Xml;
using System.Linq;
using System.Windows.Forms;


namespace GildedRose
{
    public class GildedRose
    {
        IList<Item> Items;

        /// <summary>
        /// Constructos GildedRose with List as parameter
        /// </summary>
        public GildedRose(IList<Item> Items)
        {
            this.Items = Items;
        }

        /// <summary>
        /// Constructos GildedRose overload without parameters
        /// </summary>
        public GildedRose()
        {
        }


        /// <summary>
        /// Function UpdateQuality will update the properties SellIn, Quality for each team 
        /// for the period of 1 month of 31 days 
        /// </summary>
        /// <returns>
        /// return void
        /// </returns>
        public void UpdateQuality()
        {

            try
            {

                DataSet dsItems = new DataSet();
                //Get the Xml items from Start-up Path Application + value from AppSettings
                dsItems.ReadXml(Application.StartupPath + Properties.Settings.Default.ItemXml.ToString());
                DataTable dtItems = dsItems.Tables[0]; 

                //Copy the Original Data Table (items) to copy the Original information 
                DataTable dtItemsOriginal = dtItems.Copy();

                //Read the Item Rules configuration xml
                XmlDocument xmlRules =new XmlDocument();
                //Get the Xml Items Rules from Start-up Path Application + value from AppSettings
                xmlRules.Load(Application.StartupPath + Properties.Settings.Default.ItemRulesXml.ToString());

                //Write the log file
                using (StreamWriter writer = new StreamWriter("Result.text"))
                {
                    //Begin Loop from 0 to 30 (1 month with 31 days)
                    for(int iday=0; iday< 31;iday++)
                    {

                        try
                        {

                            //Write the header for each day
                            writer.WriteLine("-------- day " + iday + " --------");
                            Console.WriteLine("-------- day " + iday + " --------");
                            writer.WriteLine("name, sellIn, quality");
                            Console.WriteLine("name, sellIn, quality");

                            //Read each item row from Item table
                            foreach (DataRow itemRow in dtItems.Rows)
                            {
                                try
                                {
                                    //Write the status of item before modification 
                                    writer.WriteLine(itemRow["ItemId"].ToString() + ", " + itemRow["SellIn"].ToString() + ", " + itemRow["Quality"].ToString());
                                    Console.WriteLine(itemRow["ItemId"].ToString() + ", " + itemRow["SellIn"].ToString() + ", " + itemRow["Quality"].ToString());

                                    //Declare Variables 
                                    int iQuality = 0, iSellIn = 0, iOriginalSellIn = 0, iBeforeSellIn = 0, iAfterSellIn = 0, iMinQuality = 0, iMaxQuality = 0;
                                    bool IsmutateQuality = false, IsmutateSellIn = false;

                                    //select Original SellIn Rule from Items Origin table  
                                    var querySellIn = from t in dtItemsOriginal.AsEnumerable()
                                                      where t.Field<string>("ItemNum") == itemRow["ItemNum"].ToString()
                                                      select t["SellIn"];

                                    //Get the SellIn value from linq statement 
                                    foreach (var rSellIn in querySellIn)
                                        iOriginalSellIn = Convert.ToInt32(rSellIn);

                                    //get Quality and SellIn values from table that will be modified through the process
                                    iQuality = Convert.ToInt32(itemRow["Quality"].ToString());
                                    iSellIn = Convert.ToInt32(itemRow["SellIn"].ToString());

                                    //Read the Rules for each item from Rules.xml
                                    XmlNode xmlRulesItem = xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/RulesItem");

                                    //Identify if the xmlRulesItem is null
                                    if (xmlRulesItem == null)
                                    {
                                        //the XmlRuleItem is null
                                        //get default values for the item
                                        iBeforeSellIn = Convert.ToInt32(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/BeforeSellIn").InnerText);
                                        iAfterSellIn = Convert.ToInt32(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/AfterSellIn").InnerText);
                                        iMinQuality = Convert.ToInt32(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/MinQuality").InnerText);
                                        iMaxQuality = Convert.ToInt32(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/MaxQuality").InnerText);
                                        IsmutateQuality = Convert.ToBoolean(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/mutateQuality").InnerText);
                                        IsmutateSellIn = Convert.ToBoolean(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/mutateSellIn").InnerText);
                      
                                    }
                                    else //Item with one Rule or More
                                    {
                                        //Declare as the XmlNode cannot be converted easily as Datatable
                                        DataSet dtsItemRules = new DataSet();
                                        //convert XmlNode Output XML into string 
                                        StringReader strItemRules = new StringReader(xmlRulesItem.OuterXml);
                                        // load the string (XML) into DataSet
                                        dtsItemRules.ReadXml(strItemRules);
                                        //Get the Rules from data table 
                                        DataTable dtItemRules = dtsItemRules.Tables[0];
                                        dtItemRules.DefaultView.Sort = "LimitDays ASC";

                                        int iLimitdayMax = Convert.ToInt32(dtItemRules.Rows[0]["LimitDays"].ToString()); //Get Max value of limitDay
                                        int iLimitdayMin = Convert.ToInt32(dtItemRules.Rows[dtItemRules.Rows.Count - 1]["LimitDays"].ToString()); //Get Min value of limitDay

                                        //If there is only one Rule, the LimitDayMin is 0
                                        if (dtItemRules.Rows.Count == 1)
                                            iLimitdayMin = 0;

                                        //Validation, the limitday can not be negative 
                                        if (iLimitdayMin < 0)
                                        {
                                            writer.WriteLine("Error " + itemRow["ItemId"].ToString() + ", Limitday: " + iLimitdayMin.ToString() + ", LimitDay can not be negative, LimitDay must '0' or bigger ");
                                            Console.WriteLine("Error " + itemRow["ItemId"].ToString() + ", Limitday: " + iLimitdayMin.ToString() + ", LimitDay can not be negative, LimitDay must '0' or bigger  ");
                                            continue;
                                        }


                                        string strWhereRuleId = "";

                                        //Read each Rule 
                                        for (int ilstCount = 0; ilstCount < dtItemRules.Rows.Count; ilstCount++)
                                        {

                                            if (iSellIn > iLimitdayMax)
                                            {
                                                //This if will be execute if the SellIn is not between the Rules
                                                //the default value configured will be taken 
                                                strWhereRuleId = String.Empty;
                                                iMinQuality = Convert.ToInt32(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/MinQuality").InnerText);
                                                iMaxQuality = Convert.ToInt32(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/MaxQuality").InnerText);
                                                iAfterSellIn = Convert.ToInt32(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/AfterSellIn").InnerText);
                                                iBeforeSellIn = Convert.ToInt32(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/BeforeSellIn").InnerText);
                                                IsmutateQuality = Convert.ToBoolean(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/mutateQuality").InnerText);
                                                IsmutateSellIn = Convert.ToBoolean(xmlRules.SelectSingleNode("Rules/RulesCategory[ItemNum='" + itemRow["ItemNum"].ToString() + "']/mutateSellIn").InnerText);
                                                break;
                                            }

                                            if (iSellIn <= iLimitdayMin)
                                            {
                                                // this if will be executed if the SellIn is less than 0
                                                // the Quality will change to minimum qty configured  
                                                strWhereRuleId = String.Empty;
                                                var resultQuery = from t in dtItemRules.AsEnumerable()
                                                                  where t.Field<string>("RuleId") == dtItemRules.Rows[ilstCount]["RuleId"].ToString()
                                                                  select new
                                                                  {
                                                                      MinQuality = t.Field<string>("MinQuality"),
                                                                      mutateQuality = t.Field<string>("mutateQuality"),
                                                                      mutateSellIn = t.Field<string>("mutateSellIn"),
                                                                  };

                                                foreach (var resultRow in resultQuery)
                                                {
                                                    iQuality = Convert.ToInt32(resultRow.MinQuality);
                                                    IsmutateQuality = Convert.ToBoolean(resultRow.mutateQuality);
                                                    IsmutateSellIn = Convert.ToBoolean(resultRow.mutateSellIn);
                                                }

                                                break;
                                            } // end  if(iSellIn <= iLimitdayMin)

                                            //Validate if it is the last row in the data table
                                            if ((ilstCount + 1) == dtItemRules.Rows.Count)
                                            {
                                                /*I am doing between the row before the last row and the minimun limit day variable against the SellIn of the Item
                                                Example Sellin between penultimate row and last row*/
                                                int iLastRowCount = 0;

                                                //Validate how many rules has the item
                                                if (dtItemRules.Rows.Count == 1)
                                                    iLastRowCount = ilstCount; // this code is executed for only one Rule 
                                                else
                                                    iLastRowCount = ilstCount - 1; //this is executed if the item has more than one Rule 


                                                if (int.Parse(dtItemRules.Rows[iLastRowCount]["LimitDays"].ToString()) >= iSellIn && iLimitdayMin < iSellIn)
                                                {
                                                    strWhereRuleId = dtItemRules.Rows[iLastRowCount]["RuleId"].ToString();
                                                    break;
                                                }
                                            }

                                            // Validate rules rows that are not the last and not the first row 
                                            //Example row with values from 10 to 0, I am validating from 9 to 1 rows  
                                            if (int.Parse(dtItemRules.Rows[ilstCount]["LimitDays"].ToString()) >= iSellIn && int.Parse(dtItemRules.Rows[ilstCount + 1]["LimitDays"].ToString()) < iSellIn)
                                            {
                                                strWhereRuleId = dtItemRules.Rows[ilstCount]["RuleId"].ToString();
                                                break;
                                            }

                                        }

                                        //get the values from data items Rules base on the RuleId
                                        if (!String.IsNullOrEmpty(strWhereRuleId))
                                        {
                                            var resultQuery = from t in dtItemRules.AsEnumerable()
                                                              where t.Field<string>("RuleId") == strWhereRuleId
                                                              select new
                                                              {
                                                                  MinQuality = t.Field<string>("MinQuality"),
                                                                  MaxQuality = t.Field<string>("MaxQuality"),
                                                                  LimitDays = t.Field<string>("LimitDays"),
                                                                  AfterSellIn = t.Field<string>("AfterSellIn"),
                                                                  BeforeSellIn = t.Field<string>("BeforeSellIn"),
                                                                  mutateQuality = t.Field<string>("mutateQuality"),
                                                                  mutateSellIn = t.Field<string>("mutateSellIn"),
                                                              };

                                            foreach (var resultRow in resultQuery)
                                            {
                                                iMinQuality = Convert.ToInt32(resultRow.MinQuality);
                                                iMaxQuality = Convert.ToInt32(resultRow.MaxQuality);
                                                iBeforeSellIn = Convert.ToInt32(resultRow.BeforeSellIn);
                                                iAfterSellIn = Convert.ToInt32(resultRow.AfterSellIn);
                                                IsmutateQuality = Convert.ToBoolean(resultRow.mutateQuality);
                                                IsmutateSellIn = Convert.ToBoolean(resultRow.mutateQuality);
                                            }
                                        }// end  if (!String.IsNullOrEmpty(strWhereClause))

                                    } //end if number of rule for item


                                    //if the Quality value can change, the code will be executed 
                                    if (IsmutateQuality)
                                    {
                                        //Update or decrease the quality 
                                        if (iday < iOriginalSellIn)
                                            iQuality = iQuality + iBeforeSellIn;
                                        else
                                            iQuality = iQuality + iAfterSellIn;

                                        // if iQuality is less than minimun quantiy take the value from minimun quality 
                                        if (iQuality <= iMinQuality)
                                            iQuality = iMinQuality;

                                        // if iQuality is more than maximun quantiy take the value from maximun quality
                                        if (iQuality >= iMaxQuality)
                                            iQuality = iMaxQuality;
                                    }

                                    //if the Sellin value can change, the code will be executed 
                                    if(IsmutateSellIn)
                                        iSellIn = iSellIn - 1;

                                    itemRow["Quality"] = iQuality;
                                    itemRow["SellIn"] = iSellIn;
                                }
                                catch (Exception ex)
                                {
                                    writer.WriteLine("Error on item" + itemRow["ItemId"].ToString() + ", description: " + ex.Message);
                                    Console.WriteLine("Error on item" + itemRow["ItemId"].ToString() + ", description: " + ex.Message);
                                    continue;
                                }


                            } // End  foreach(DataRow itemRow in dtItems.Rows)
                            writer.WriteLine(String.Empty);
                            Console.WriteLine(String.Empty);

                        }
                        catch (Exception ex)
                        {
                            writer.WriteLine("Error on day" + iday + ", description: " + ex.Message);
                            Console.WriteLine("Error on day" + iday + ", description: " + ex.Message);
                            continue;
                        }
                    } // End  for(int iday=0; iday< 31;iday++
                } //End Using StreamWritter
            }
            catch(Exception ex)
            {
                Console.WriteLine("General Error on function UpdateQuality(), description: " + ex.Message);
            }
        } //End function 
    }
}
